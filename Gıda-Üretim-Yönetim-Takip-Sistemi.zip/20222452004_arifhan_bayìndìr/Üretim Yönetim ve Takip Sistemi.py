from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from PIL import ImageTk, Image
import mysql.connector
import tkinter as tk

win = Tk()

win.title("Giriş")

win.geometry("700x400+500+100")

win.resizable(width=False, height=False)

myFont = ("Times New Roman", 11)

labelFont = ("Whisper", 30)

win.config(bg="peru")



user_rights = 3

def login():
    global user_rights

    username = nameEntry.get()

    password = passwordEnrty.get()

    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="SavorLuxeCuisine"
    )

    cursor = conn.cursor()


    cursor.execute("SELECT * FROM personel WHERE personel_adı = %s AND personel_şifre = %s", (username, password))
    result = cursor.fetchone()

    if result:
        messagebox.showinfo("Başarılı", "Giriş başarılı!")
        Anasayfa()
    else:
        messagebox.showerror("Hata", "Geçersiz kullanıcı adı veya şifre.")
        decrement_user_rights()
        clear()

    conn.close()

def decrement_user_rights():
    global user_rights
    user_rights -= 1

    if user_rights == 0:
        messagebox.showinfo("Haklarınız Bitmiştir", "Program kapatılıyor.")
        win.destroy()

def clear():
    nameEntry.delete(0, END)
    passwordEnrty.delete(0, END)


def veriGetir():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="SavorLuxeCuisine"
    )

    my_cursor = conn.cursor()

    my_cursor.execute("SELECT * FROM planlama")

    result = my_cursor.fetchall()



    plan_tree.column("ID",width=35,anchor='w')

    plan_tree.column("Bilgi",width=90,anchor='w')

    plan_tree.column("Ürün",width=84,anchor='w')

    plan_tree.column("Marka",width=102,anchor='w')

    plan_tree.column("İşçi Sayı",width=45,anchor='w')

    plan_tree.column("Malzeme Sayı",width=48,anchor='w')

    plan_tree.column("Makine",width=93,anchor='w')

    plan_tree.column("Başlangıç Tarih",width=97,anchor='w')

    plan_tree.column("Bitiş Tarih",width=83,anchor='w')

    plan_tree.column("Durum 1",width=50,anchor='w')

    plan_tree.column("Durum 2",width=45,anchor='w')

    plan_tree.heading("ID",text="ID",anchor='w')

    plan_tree.heading("Bilgi",text="Bilgi",anchor='w')

    plan_tree.heading("Ürün",text="Ürün",anchor='w')

    plan_tree.heading("Marka",text="Marka",anchor='w')

    plan_tree.heading("İşçi Sayı",text="İşçi Sayı",anchor='w')

    plan_tree.heading("Malzeme Sayı",text="Malzeme Sayı",anchor='w')

    plan_tree.heading("Makine",text="Makine",anchor='w')

    plan_tree.heading("Başlangıç Tarih",text="Başlangıç Tarih",anchor='w')

    plan_tree.heading("Bitiş Tarih",text="Bitiş Tarih",anchor='w')

    plan_tree.heading("Durum 1",text="Durum 1",anchor='w')

    plan_tree.heading("Durum 2",text="Durum 2",anchor='w')

    for x in result:
        plan_tree.insert('',END,values=x)



def Anasayfa():


    global stokTree,plan_tree,personelTree


    win.destroy()

    pen = tk.Tk()

    pen.title("AnaSayfa")

    pen.geometry("1000x400+470+100")

    pen.resizable(width=False, height=False)

    myFont = ("Poppins", 10)

    labelFont = ("Whisper", 30)


    def planlamaMenu():




        def veriEkle():



            try:
                conn = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",
                    database="SavorLuxeCuisine"
                )

                cursor = conn.cursor()

                bilgi = bilgiEnrty.get()
                ad = ürünAdEnrty.get()
                marka = ürünMarkaEntry.get()
                işçi = int(işçiEntry.get())
                malzeme = int(malzemeEnrty.get())
                makine = makineEnrty.get()
                baslangıc = tarihEntry.get()
                bitis = bitisEntry.get()
                durum1 = var_1.get()
                durum2 = var_2.get()

                query = ("INSERT INTO planlama(plan_bilgi, ürün_adı, ürün_marka, işçilik_sayı, "
                         "malzeme_sayı, makine_ad, başlangıç_tarih, bitiş_tarih, durum, durum2) "
                         "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)")
                values = (bilgi, ad, marka, işçi, malzeme, makine, baslangıc, bitis, durum1, durum2)
                cursor.execute(query, values)


                conn.commit()

                messagebox.showinfo("Sonuç", "Ekleme Başarılı.")

                bilgiEnrty.delete(0, END)

                ürünAdEnrty.delete(0, END)

                ürünMarkaEntry.delete(0, END)

                işçiEntry.delete(0, END)

                malzemeEnrty.delete(0, END)

                makineEnrty.delete(0, END)

                tarihEntry.delete(0, END)

                bitisEntry.delete(0, END)

                checkbox_1.deselect()

                checkbox_2.deselect()

            except Exception as e:

                messagebox.showerror("Hata", f"Değerlerinizi Kontrol Ediniz. Hata: {str(e)}")

                bilgiEnrty.delete(0, END)

                ürünAdEnrty.delete(0, END)

                ürünMarkaEntry.delete(0, END)

                işçiEntry.delete(0, END)

                malzemeEnrty.delete(0, END)

                makineEnrty.delete(0, END)

                tarihEntry.delete(0, END)

                bitisEntry.delete(0, END)

                checkbox_1.deselect()

                checkbox_2.deselect()

            finally:
                cursor.close()
                conn.close()


        pen.destroy()
        root = Tk()

        root.title("Planlama Menu")

        root.geometry("700x400+500+100")

        root.resizable(width=False, height=False)

        root.config(bg="peru")

        myFont = ("Poppins", 11)

        baslıkLabel = Label(root, text="Üretim Planlama  ", font=myFont, bg="peru")

        bilgiLabel = Label(root, text="Bilgi : ", font=myFont, bg="peru")

        ürünBilgiLabel = Label(root, text="Ürün Bilgisi : ", font=myFont, bg="peru")

        ürünAdLabel = Label(root, text="Ürün Adı : ", font=myFont, bg="peru")

        ürünMarkaLabel = Label(root, text="Ürün Markası : ", font=myFont, bg="peru")

        işçilikLabel = Label(root, text="İşçilik Planlaması : ", font=myFont, bg="peru")

        işçiSayiLabel = Label(root, text="İşçilik Sayısı : ", font=myFont, bg="peru")

        malzemePlan = Label(root, text="Malzeme Planlaması : ", font=myFont, bg="peru")

        malzemeAdi = Label(root, text="Malzeme Sayısı : ", font=myFont, bg="peru")

        makinePlan = Label(root, text="Makine Planlama : ", font=myFont, bg="peru")

        makineAdi = Label(root, text="Makine Adi : ", font=myFont, bg="peru")

        tarihLabel=Label(root, text="Üretim Tarihi : ", font=myFont, bg="peru")

        bitisLabel=Label(root, text="Bitiş Tarihi : ", font=myFont, bg="peru")

        durumLabel = Label(root, text="Öncelik ve Acil Durumlar", bg="peru")

        var_1 = IntVar()

        var_2 = IntVar()

        checkbox_1 = Checkbutton(root, text="Öncelikli İş", variable=var_1,bg="peru",font=myFont)

        checkbox_2 = Checkbutton(root, text="Acil Durum", variable=var_2,bg="peru",font=myFont)

        myButton=Button(root,text="Plan Oluştur",bg="black",fg="white",command=veriEkle)

        tarihEntry = Entry(root, width=20)

        malzemeEnrty = Entry(root, width=20)

        makineEnrty = Entry(root, width=20)

        işçiEntry = Entry(root, width=20)

        ürünAdEnrty = Entry(root, width=20)

        ürünMarkaEntry = Entry(root, width=20)

        bilgiEnrty = Entry(root, width=20)

        bilgiEnrty = Entry(root, width=20)

        bitisEntry=Entry(root, width=20)

        baslıkLabel.place(x=280, y=20)

        bilgiLabel.place(x=35,y=65)

        bilgiEnrty.place(x=90,y=67)

        ürünBilgiLabel.place(x=35,y=105)

        ürünAdLabel.place(x=35,y=150)

        ürünAdEnrty.place(x=110,y=150)

        ürünMarkaLabel.place(x=35,y=190)

        ürünMarkaEntry.place(x=140,y=190)

        işçilikLabel.place(x=35,y=230)

        işçiSayiLabel.place(x=35,y=270)

        işçiEntry.place(x=180,y=270)

        malzemePlan.place(x=35,y=310)

        malzemeAdi.place(x=35,y=350)

        malzemeEnrty.place(x=180,y=350)

        makinePlan.place(x=340,y=80)

        makineAdi.place(x=340,y=115)

        makineEnrty.place(x=460,y=115)

        tarihLabel.place(x=340,y=160)

        tarihEntry.place(x=460,y=160)

        bitisLabel.place(x=340,y=200)

        bitisEntry.place(x=460,y=200)

        durumLabel.place(x=340,y=245)

        checkbox_1.place(x=340,y=270)

        checkbox_2.place(x=340,y=290)

        myButton.place(x=360,y=335)

        root.mainloop()


    def personelYönetim():

        def veriEkle():

            try:
                conn = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",
                    database="SavorLuxeCuisine"
                )

                cursor = conn.cursor()

                isim = nameEntry.get()
                surname= soyisimEntry.get()
                age = int(yasEntry.get())
                gorev = gorevEntry.get()
                password=şifreEntry.get()

                query = ("INSERT INTO personel(personel_adı,personel_soyadı,personel_yas,"
                         "personel_gorev,personel_şifre) "
                         "VALUES (%s, %s, %s, %s, %s")
                values = (isim, surname, age, gorev, password)
                cursor.execute(query, values)


                conn.commit()
                messagebox.showinfo("Sonuç", "Ekleme Başarılı.")
                nameEntry.delete(0, END)
                soyisimEntry.delete(0, END)
                yasEntry.delete(0, END)
                gorevEntry.delete(0, END)
                şifreEntry.delete(0, END)

            except Exception as e:
                messagebox.showerror("Hata", f"Değerlerinizi Kontrol Ediniz. Hata: {str(e)}")
                nameEntry.delete(0, END)
                soyisimEntry.delete(0, END)
                yasEntry.delete(0, END)
                gorevEntry.delete(0, END)
                şifreEntry.delete(0, END)

            finally:
                cursor.close()
                conn.close()




        def personelRapor():

            personel.destroy()

            perRapor = Tk()

            perRapor.title("Personel Rapor")

            perRapor.geometry("700x400+500+100")

            perRapor.resizable(width=False, height=False)

            myFont = ("Poppins", 10)

            labelFont = ("Whisper", 30)

            perRapor.config(bg="peru")

            def personelGetir():
                conn = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",
                    database="SavorLuxeCuisine"
                )

                my_cursor = conn.cursor()

                my_cursor.execute("SELECT * FROM personel")

                result = my_cursor.fetchall()

                personelTree.column("ID", width=70, anchor='w')

                personelTree.column("Ad", width=70, anchor='w')

                personelTree.column("Soyad", width=70, anchor='w')

                personelTree.column("Yas", width=70, anchor='w')

                personelTree.column("Gorev", width=90, anchor='w')

                personelTree.column("Sifre", width=70, anchor='w')

                personelTree.heading("ID", text="ID", anchor='w')

                personelTree.heading("Ad", text="Ad", anchor='w')

                personelTree.heading("Soyad", text="Soyad", anchor='w')

                personelTree.heading("Yas", text="Yas", anchor='w')

                personelTree.heading("Gorev", text="Gorev", anchor='w')

                personelTree.heading("Sifre", text="Sifre", anchor='w')



                for x in result:
                    personelTree.insert('', END, values=x)

            raporlabel = Label(perRapor, text="Rapor", font=myFont, bg="peru")

            personelTree = ttk.Treeview(perRapor)

            personelTree['columns'] = ('ID', 'Ad', 'Soyad', 'Yas', 'Gorev', 'Sifre')

            personelTree.place(x=30, y=80)

            raporlabel.place(x=280, y=20)

            personelGetir()



            perRapor.mainloop()





        pen.destroy()

        personel = Tk()

        personel.title("Personel")

        personel.geometry("700x400+500+100")

        personel.resizable(width=False, height=False)

        myFont = ("Poppins", 10)

        labelFont = ("Whisper", 30)

        personel.config(bg="peru")

        myMenu = Menu(personel)

        personel.config(menu=myMenu, bg="peru")

        personelRaporMenu = Menu(myMenu)

        myMenu.add_cascade(label="Personel Rapor", menu=personelRaporMenu)

        personelRaporMenu.add_command(label="Rapor", command=personelRapor, font=myFont)

        baslikLabel = Label(personel, text="Personel Yönetim", font=myFont, bg="peru")

        isimLabel=Label(personel, text="Personel Adı : ", font=myFont, bg="peru")

        soyisimLabel = Label(personel, text="Personel Soyadı : ", font=myFont, bg="peru")

        yasLabel=Label(personel, text="Personel Yaşı : ", font=myFont, bg="peru")

        gorevLabel = Label(personel, text="Personel Görevi : ", font=myFont, bg="peru")

        şifreLabel=Label(personel, text="Personel Şifre : ", font=myFont, bg="peru")

        myButton=Button(personel,text="Personel Ekle",width=20,bg="black",fg="white",command=veriEkle)

        isimEntry=Entry(personel,width=20)

        soyisimEntry = Entry(personel, width=20)

        yasEntry = Entry(personel, width=20)

        gorevEntry = Entry(personel, width=20)

        şifreEntry = Entry(personel, width=20)

        baslikLabel.place(x=280, y=20)

        isimLabel.place(x=130, y=90)

        soyisimLabel.place(x=130, y=125)

        yasLabel.place(x=130, y=160)

        gorevLabel.place(x=130, y=195)

        şifreLabel.place(x=130, y=230)

        isimEntry.place(x=250, y=90)

        soyisimEntry.place(x=250, y=125)

        yasEntry.place(x=250, y=160)

        gorevEntry.place(x=250, y=195)

        şifreEntry.place(x=250, y=230)

        myButton.place(x=250, y=270)






        personel.mainloop()

    def üretimAnaliz():

        def analizYap():

            try:
                urun_sayisi = float(ürünEntry.get())
                calisma_saatleri = float(çalışmaEntry.get())

                verimlilik_orani = urun_sayisi / calisma_saatleri
                analizSonuc.config(text=f"Üretim Verimliliği Oranı : {verimlilik_orani:.2f}")

                # Örnek bir kriter: 2.0'den büyükse "İyi", küçükse "Kötü"
                if verimlilik_orani > 2.0:
                    messagebox.showinfo("Sonuç", "Üretim verimliliği İyi!")
                    ürünEntry.delete(0,END)
                    çalışmaEntry.delete(0, END)
                    analizSonuc["text"]=""

                else:
                    messagebox.showinfo("Sonuç", "Üretim verimliliği Kötü.")
                    ürünEntry.delete(0, END)
                    çalışmaEntry.delete(0, END)
                    analizSonuc["text"] = ""

            except ValueError:
                messagebox.showerror("Hata", "Lütfen geçerli sayısal değerler girin.")
                ürünEntry.delete(0, END)
                çalışmaEntry.delete(0, END)
                analizSonuc["text"] = ""



        pen.destroy()



        analiz=Tk()

        analiz.title("Analiz")

        analiz.geometry("700x400+500+100")

        analiz.resizable(width=False, height=False)

        myFont = ("Poppins", 10)

        labelFont = ("Whisper", 30)

        analiz.config(bg="peru")

        baslikLabel=Label(analiz,text="Üretim Analiz",font=myFont,bg="peru")

        ürünSayı=Label(analiz,text="Üretilen Ürün Sayısı : ",font=myFont,bg="peru")

        çalışılanSaat = Label(analiz, text="Çalışılan Saat Sayısı : ", font=myFont,bg="peru")

        analizSonuc=Label(analiz,text="",font=myFont,bg="peru")

        ürünEntry=Entry(analiz,width=20)

        çalışmaEntry=Entry(analiz,width=20)

        analizButton=Button(analiz,text="Analiz Yap" , font=myFont,bg="black",fg="white",command=analizYap)

        baslikLabel.place(x=300, y=20)

        ürünSayı.place(x=130, y=90)

        çalışılanSaat.place(x=130, y=125)

        ürünEntry.place(x=260, y=90)

        çalışmaEntry.place(x=260, y=125)

        analizButton.place(x=260, y=160)

        analizSonuc.place(x=260,y=200)

        analiz.mainloop()



    def stokTakip():

            def veriEkle():

                try:
                    conn = mysql.connector.connect(
                        host="localhost",
                        user="root",
                        password="",
                        database="SavorLuxeCuisine"
                    )

                    cursor = conn.cursor()


                    malzeme = malzemeEnrty.get()

                    miktar = int(miktarEntry.get())

                    query = ("INSERT INTO stok(malzeme_adı,miktar VALUES (%s, %s, %s")
                    values = (malzeme,miktar)
                    cursor.execute(query, values)


                    conn.commit()
                    messagebox.showinfo("Sonuç", "Ekleme Başarılı.")

                    malzemeEnrty.delete(0, END)

                    miktarEntry.delete(0, END)


                except Exception as e:
                    messagebox.showerror("Hata", f"Değerlerinizi Kontrol Ediniz. Hata: {str(e)}")

                    malzemeEnrty.delete(0, END)

                    miktarEntry.delete(0, END)

                finally:
                    cursor.close()
                    conn.close()

            def raporStok():

                stok.destroy()

                stRp=Tk()



                stRp.title("Stok Rapor")

                stRp.geometry("700x400+500+100")

                stRp.resizable(width=False, height=False)

                myFont = ("Poppins", 11)

                stRp.config(bg="peru")

                def stokGetir():
                    conn = mysql.connector.connect(
                        host="localhost",
                        user="root",
                        password="",
                        database="SavorLuxeCuisine"
                    )

                    my_cursor = conn.cursor()

                    my_cursor.execute("SELECT * FROM stok")

                    result = my_cursor.fetchall()

                    stokTree.column("ID", width=70, anchor='w')

                    stokTree.column("Malzeme", width=70, anchor='w')

                    stokTree.column("Miktar", width=70, anchor='w')

                    stokTree.heading("ID", text="ID", anchor='w')

                    stokTree.heading("Malzeme", text="Malzeme", anchor='w')

                    stokTree.heading("Miktar", text="Miktar", anchor='w')
                    for x in result:
                        stokTree.insert("", END, values=x)



                raporLabel=Label(stRp, text="Rapor", font=myFont, bg="peru")

                stokTree = ttk.Treeview(stRp)

                stokTree['columns'] = ('ID','Malzeme','Miktar')

                stokTree.place(x=30, y=80)

                raporLabel.place(x=300, y=20)

                stokGetir()

                stRp.mainloop()



            global stok


            pen.destroy()

            stok = Tk()

            stok.title("Stok Menu")

            stok.geometry("700x400+500+100")

            stok.resizable(width=False, height=False)

            myFont = ("Poppins", 11)

            myMenu = Menu(stok)

            stok.config(menu=myMenu, bg="peru")

            stokRapor = Menu(myMenu)

            myMenu.add_cascade(label="Stok Rapor", menu=stokRapor)

            stokRapor.add_command(label="Rapor", command=raporStok, font=myFont)

            baslikLabel = Label(stok, text="Stok Takip", font=myFont, bg="peru")

            malzemeAdi = Label(stok, text="Malzeme Adı :", font=myFont, bg="peru")

            miktarLabel = Label(stok, text="Miktar :", font=myFont, bg="peru")

            myButton = Button(stok, text="Stok Girişi", bg="black", fg="white", font=myFont,command=veriEkle)

            malzemeEnrty = Entry(stok, width=20)

            miktarEntry = Entry(stok, width=20)

            baslikLabel.place(x=300, y=20)

            malzemeAdi.place(x=130, y=90)

            miktarLabel.place(x=130, y=125)

            malzemeEnrty.place(x=240, y=90)

            miktarEntry.place(x=240, y=125)

            myButton.place(x=240, y=170)

            stok.mainloop()


    myMenu = Menu(pen)

    pen.config(menu=myMenu, bg="peru")

    üretimMenu = Menu(myMenu)

    stokMenu=Menu(myMenu)

    analizMenu=Menu(myMenu)

    personelMenu=Menu(myMenu)

    myMenu.add_cascade(label="Üretim", menu=üretimMenu)

    üretimMenu.add_command(label="Planlama", command=planlamaMenu, font=myFont)

    myMenu.add_cascade(label="Stok Takip",menu=stokMenu)

    stokMenu.add_command(label="Stok", command=stokTakip, font=myFont)

    myMenu.add_cascade(label="Personel", menu=personelMenu)

    personelMenu.add_command(label="Yönetim", command=personelYönetim, font=myFont)

    myMenu.add_cascade(label="Analiz", menu=analizMenu)

    analizMenu.add_command(label="Analiz", command=üretimAnaliz, font=myFont)



    pen.iconbitmap(r"D:\Python Uygulamalar\Proje\images\icon.ico")

    myLogo = ImageTk.PhotoImage(Image.open("D:\Python Uygulamalar\Proje\images\logo3.png"))

    myLabel = Label(pen, text="SavorLuxe Cuisine", font=labelFont, bg="peru")

    myImage = Label(pen, image=myLogo, width=50, height=50, bg="peru")



    plan_tree=ttk.Treeview(pen)

    plan_tree['columns']=('ID','Bilgi','Ürün','Marka','İşçi Sayı','Malzeme Sayı','Makine',
                          'Başlangıç Tarih','Bitiş Tarih','Durum 1','Durum 2')

    plan_tree.place(x=30, y=105)



    plan_tree.place(x=18,y=115)



    myLabel.place(x=95, y=25)

    myImage.place(x=20, y=25)

    veriGetir()




    pen.mainloop()


myLogo = ImageTk.PhotoImage(Image.open("D:\Python Uygulamalar\Proje\images\logo3.png"))

myLabel = Label(win, text="SavorLuxe Cuisine", font=labelFont, bg="peru")

myImage = Label(win, image=myLogo, width=50, height=50, bg="peru")

nameLabel = Label(win, text="İsminiz : ", font=myFont, bg="peru")

passwordLabel = Label(win, text="Şifreniz : ", font=myFont, bg="peru")

nameEntry = Entry(win, width=20)

passwordEnrty = Entry(win, width=20, show="*")

girisButton = Button(win, text="Giriş", font=myFont, width=10, command=login)

myLabel.place(x=95, y=25)

myImage.place(x=20, y=25)

nameLabel.place(x=220, y=150)

passwordLabel.place(x=220, y=190)

nameEntry.place(x=300, y=150)

passwordEnrty.place(x=300, y=190)

girisButton.place(x=310, y=240)

win.mainloop()



