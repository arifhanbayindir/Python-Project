-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 23 Ara 2023, 22:02:47
-- Sunucu sürümü: 8.0.31
-- PHP Sürümü: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `savorluxecuisine`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `personel`
--

DROP TABLE IF EXISTS `personel`;
CREATE TABLE IF NOT EXISTS `personel` (
  `personel_id` int NOT NULL AUTO_INCREMENT,
  `personel_adı` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `personel_soyadı` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `personel_yas` int DEFAULT NULL,
  `personel_gorev` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `personel_şifre` varchar(100) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  PRIMARY KEY (`personel_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `personel`
--

INSERT INTO `personel` (`personel_id`, `personel_adı`, `personel_soyadı`, `personel_yas`, `personel_gorev`, `personel_şifre`) VALUES
(1, 'Arif', 'Bayındır', 20, 'Proje Yöneticisi', 'savorlux123'),
(2, 'Lare', 'Deniz', 19, 'Proje Yöneticisi Yardımcı', 'cuisine456'),
(3, 'Eriç', 'Dulak', 24, 'Yazılım Geliştirici', ''),
(4, 'Lerin', 'Fert', 26, 'Yazılım Geliştirici', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `planlama`
--

DROP TABLE IF EXISTS `planlama`;
CREATE TABLE IF NOT EXISTS `planlama` (
  `planlama_id` int NOT NULL AUTO_INCREMENT,
  `plan_bilgi` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `ürün_adı` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `ürün_marka` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `işçilik_sayı` int DEFAULT NULL,
  `malzeme_sayı` int DEFAULT NULL,
  `makine_ad` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `başlangıç_tarih` datetime DEFAULT NULL,
  `bitiş_tarih` datetime DEFAULT NULL,
  `durum` tinyint(1) DEFAULT NULL,
  `durum2` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`planlama_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `planlama`
--

INSERT INTO `planlama` (`planlama_id`, `plan_bilgi`, `ürün_adı`, `ürün_marka`, `işçilik_sayı`, `malzeme_sayı`, `makine_ad`, `başlangıç_tarih`, `bitiş_tarih`, `durum`, `durum2`) VALUES
(1, 'Karides Üretim', 'Karides', 'İsveç Karides', 400, 700, 'D1,D2,D3,D4,D5', '2023-03-05 00:00:00', '2023-03-25 00:00:00', 1, 0),
(2, 'Karides Üretim', 'Karides', 'İsveç Karides', 400, 700, 'D1,D2,D3,D4,D5', '2023-03-05 00:00:00', '2023-03-25 00:00:00', 1, 0),
(3, 'Somon Üretim', 'Somon', 'Norveç Somon', 1000, 5000, 'E1,E2,E3E4', '2023-06-20 00:00:00', '2023-07-15 00:00:00', 1, 0),
(4, 'Ahtapot Üretim', 'Ahtapot', 'Danimarka Ahtapot', 500, 1000, 'N1,N2,N3', '2023-08-30 00:00:00', '2023-09-10 00:00:00', 0, 1),
(5, '4', 'Hamsi', 'Karadeniz Hamsi', 300, 700, 'S1,S2,S3', '2023-07-12 00:00:00', '2023-08-01 00:00:00', 1, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `stok`
--

DROP TABLE IF EXISTS `stok`;
CREATE TABLE IF NOT EXISTS `stok` (
  `stok_id` int NOT NULL AUTO_INCREMENT,
  `malzeme_adı` varchar(50) COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `miktar` int DEFAULT NULL,
  PRIMARY KEY (`stok_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_turkish_ci;

--
-- Tablo döküm verisi `stok`
--

INSERT INTO `stok` (`stok_id`, `malzeme_adı`, `miktar`) VALUES
(1, 'Somon', 500),
(4, 'Karides', 1000),
(5, 'Ahtapot', 200);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
